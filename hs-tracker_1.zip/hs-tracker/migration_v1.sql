-- =============================================
-- HS Engineering - Tracker Dossiers Bailleur
-- Migration V1 - Coller dans Supabase SQL Editor
-- =============================================

-- 1. TABLE PROJETS
CREATE TABLE IF NOT EXISTS projects (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name        TEXT NOT NULL,
  description TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- 2. TABLE SITES (dossiers)
CREATE TABLE IF NOT EXISTS sites (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id  UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  name        TEXT NOT NULL,
  bailleur    TEXT,
  region      TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- 3. TABLE DOCUMENTS (15 par site)
CREATE TABLE IF NOT EXISTS documents (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  site_id     UUID NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
  doc_type    INTEGER NOT NULL CHECK (doc_type BETWEEN 1 AND 15),
  status      TEXT NOT NULL DEFAULT 'missing'
                CHECK (status IN ('received', 'pending', 'missing')),
  notes       TEXT,
  updated_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (site_id, doc_type)
);

-- 4. TRIGGER : crée automatiquement les 15 documents quand un site est créé
CREATE OR REPLACE FUNCTION create_site_documents()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO documents (site_id, doc_type, status)
  SELECT NEW.id, gs, 'missing'
  FROM generate_series(1, 15) gs;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_create_site_documents ON sites;

CREATE TRIGGER trigger_create_site_documents
  AFTER INSERT ON sites
  FOR EACH ROW
  EXECUTE FUNCTION create_site_documents();

-- 5. INDEX pour les performances
CREATE INDEX IF NOT EXISTS idx_sites_project_id   ON sites(project_id);
CREATE INDEX IF NOT EXISTS idx_documents_site_id  ON documents(site_id);
CREATE INDEX IF NOT EXISTS idx_documents_status   ON documents(status);

-- 6. RLS désactivé pour la V1 (accès solo, pas d'auth)
ALTER TABLE projects  DISABLE ROW LEVEL SECURITY;
ALTER TABLE sites     DISABLE ROW LEVEL SECURITY;
ALTER TABLE documents DISABLE ROW LEVEL SECURITY;
