import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'

export default function ProjectsPage() {
  const navigate = useNavigate()
  const [projects, setProjects] = useState([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ name: '', description: '' })
  const [saving, setSaving] = useState(false)

  useEffect(() => { fetchProjects() }, [])

  async function fetchProjects() {
    setLoading(true)
    const { data, error } = await supabase
      .from('projects')
      .select(`
        id, name, description, created_at,
        sites(id, documents(status))
      `)
      .order('created_at', { ascending: false })

    if (!error) setProjects(data || [])
    setLoading(false)
  }

  async function createProject() {
    if (!form.name.trim()) return
    setSaving(true)
    const { error } = await supabase.from('projects').insert({
      name: form.name.trim(),
      description: form.description.trim() || null,
    })
    setSaving(false)
    if (!error) {
      setShowModal(false)
      setForm({ name: '', description: '' })
      fetchProjects()
    }
  }

  function getStats(project) {
    const sites = project.sites || []
    const totalSites = sites.length
    const completeSites = sites.filter(s =>
      (s.documents || []).filter(d => d.status === 'received').length === 15
    ).length
    const totalDocs = sites.reduce((acc, s) => acc + (s.documents || []).length, 0)
    const receivedDocs = sites.reduce((acc, s) =>
      acc + (s.documents || []).filter(d => d.status === 'received').length, 0
    )
    const pct = totalDocs > 0 ? Math.round((receivedDocs / totalDocs) * 100) : 0
    return { totalSites, completeSites, pct }
  }

  return (
    <div className="min-h-screen bg-zinc-100">
      {/* Header */}
      <div className="bg-white border-b border-zinc-200 px-4 py-4 sticky top-0 z-10">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <div>
            <p className="text-xs text-zinc-400 font-medium uppercase tracking-widest">HS Engineering</p>
            <h1 className="text-xl font-bold text-zinc-900">Projets</h1>
          </div>
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center gap-2 bg-zinc-900 text-white text-sm font-semibold px-4 py-2.5 rounded-xl active:scale-95 transition-transform"
          >
            <span className="text-base">+</span> Nouveau
          </button>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-5">
        {loading ? (
          <div className="space-y-3">
            {[1,2,3].map(i => (
              <div key={i} className="bg-white rounded-2xl p-5 animate-pulse">
                <div className="h-5 bg-zinc-100 rounded w-1/2 mb-3" />
                <div className="h-3 bg-zinc-100 rounded w-1/3 mb-4" />
                <div className="h-2 bg-zinc-100 rounded" />
              </div>
            ))}
          </div>
        ) : projects.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-4xl mb-3">📁</p>
            <p className="text-zinc-500 text-sm">Aucun projet pour l'instant</p>
            <button
              onClick={() => setShowModal(true)}
              className="mt-4 text-sm text-zinc-900 font-semibold underline underline-offset-2"
            >
              Créer le premier projet
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {projects.map(p => {
              const { totalSites, completeSites, pct } = getStats(p)
              return (
                <button
                  key={p.id}
                  onClick={() => navigate(`/project/${p.id}`)}
                  className="w-full bg-white rounded-2xl p-5 text-left shadow-sm border border-zinc-100 active:scale-98 transition-transform hover:border-zinc-200"
                >
                  <div className="flex items-start justify-between mb-1">
                    <h2 className="font-bold text-zinc-900 text-base">{p.name}</h2>
                    <span className="text-xs font-bold text-zinc-500 ml-2 mt-0.5">{pct}%</span>
                  </div>
                  {p.description && (
                    <p className="text-xs text-zinc-400 mb-3">{p.description}</p>
                  )}
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-xs text-zinc-500">
                      <span className="font-semibold text-zinc-700">{completeSites}</span>/{totalSites} dossiers complets
                    </span>
                  </div>
                  {/* Progress bar */}
                  <div className="h-1.5 bg-zinc-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-emerald-500 rounded-full transition-all duration-500"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </button>
              )
            })}
          </div>
        )}
      </div>

      {/* Modal nouveau projet */}
      {showModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center px-4 pb-4">
          <div className="bg-white rounded-2xl w-full max-w-sm p-6 shadow-xl">
            <h2 className="font-bold text-zinc-900 text-lg mb-4">Nouveau projet</h2>
            <div className="mb-3">
              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wide mb-1">Nom du projet *</label>
              <input
                autoFocus
                type="text"
                value={form.name}
                onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                placeholder="Ex : Adamaoua Zone Nord"
                className="w-full px-3 py-3 border border-zinc-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-zinc-900"
                onKeyDown={e => e.key === 'Enter' && createProject()}
              />
            </div>
            <div className="mb-5">
              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wide mb-1">Description</label>
              <input
                type="text"
                value={form.description}
                onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                placeholder="Ex : 45 sites, Région Adamaoua"
                className="w-full px-3 py-3 border border-zinc-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-zinc-900"
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => { setShowModal(false); setForm({ name: '', description: '' }) }}
                className="flex-1 py-3 border border-zinc-200 rounded-xl text-sm font-semibold text-zinc-600"
              >
                Annuler
              </button>
              <button
                onClick={createProject}
                disabled={saving || !form.name.trim()}
                className="flex-1 py-3 bg-zinc-900 text-white rounded-xl text-sm font-semibold disabled:opacity-50"
              >
                {saving ? 'Création...' : 'Créer'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
