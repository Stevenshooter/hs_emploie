import { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { STATUS } from '../lib/constants'

export default function ProjectPage() {
  const { projectId } = useParams()
  const navigate = useNavigate()
  const [project, setProject] = useState(null)
  const [sites, setSites] = useState([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ name: '', bailleur: '', region: '' })
  const [saving, setSaving] = useState(false)
  const [search, setSearch] = useState('')

  useEffect(() => { fetchData() }, [projectId])

  async function fetchData() {
    setLoading(true)
    const [{ data: proj }, { data: sitesData }] = await Promise.all([
      supabase.from('projects').select('id, name, description').eq('id', projectId).single(),
      supabase.from('sites')
        .select('id, name, bailleur, region, created_at, documents(status)')
        .eq('project_id', projectId)
        .order('created_at', { ascending: false }),
    ])
    setProject(proj)
    setSites(sitesData || [])
    setLoading(false)
  }

  async function createSite() {
    if (!form.name.trim()) return
    setSaving(true)
    const { error } = await supabase.from('sites').insert({
      project_id: projectId,
      name: form.name.trim().toUpperCase(),
      bailleur: form.bailleur.trim() || null,
      region: form.region.trim() || null,
    })
    setSaving(false)
    if (!error) {
      setShowModal(false)
      setForm({ name: '', bailleur: '', region: '' })
      fetchData()
    }
  }

  function getSiteStats(site) {
    const docs = site.documents || []
    const received = docs.filter(d => d.status === 'received').length
    const pending = docs.filter(d => d.status === 'pending').length
    const missing = docs.filter(d => d.status === 'missing').length
    const pct = Math.round((received / 15) * 100)
    const isComplete = received === 15
    return { received, pending, missing, pct, isComplete }
  }

  const filtered = sites.filter(s =>
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    (s.bailleur || '').toLowerCase().includes(search.toLowerCase())
  )

  const totalComplete = sites.filter(s => getSiteStats(s).isComplete).length

  return (
    <div className="min-h-screen bg-zinc-100">
      {/* Header */}
      <div className="bg-white border-b border-zinc-200 px-4 py-4 sticky top-0 z-10">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center gap-3 mb-3">
            <button
              onClick={() => navigate('/')}
              className="w-8 h-8 flex items-center justify-center rounded-lg bg-zinc-100 text-zinc-600 font-bold text-lg"
            >
              ‹
            </button>
            <div className="flex-1 min-w-0">
              <p className="text-xs text-zinc-400 font-medium uppercase tracking-widest">Projet</p>
              <h1 className="text-lg font-bold text-zinc-900 truncate">{project?.name || '...'}</h1>
            </div>
            <button
              onClick={() => setShowModal(true)}
              className="flex items-center gap-1.5 bg-zinc-900 text-white text-sm font-semibold px-3 py-2.5 rounded-xl active:scale-95 transition-transform"
            >
              <span>+</span> Site
            </button>
          </div>

          {/* Résumé global */}
          {!loading && sites.length > 0 && (
            <div className="flex gap-4 text-xs text-zinc-500 mb-3">
              <span><span className="font-bold text-zinc-700">{sites.length}</span> sites</span>
              <span><span className="font-bold text-emerald-600">{totalComplete}</span> complets</span>
              <span><span className="font-bold text-zinc-700">{sites.length - totalComplete}</span> en cours</span>
            </div>
          )}

          {/* Search */}
          {sites.length > 4 && (
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Rechercher un site ou un bailleur..."
              className="w-full px-3 py-2 text-sm bg-zinc-50 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900"
            />
          )}
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-5">
        {loading ? (
          <div className="space-y-3">
            {[1,2,3,4].map(i => (
              <div key={i} className="bg-white rounded-2xl p-5 animate-pulse">
                <div className="h-4 bg-zinc-100 rounded w-1/3 mb-2" />
                <div className="h-3 bg-zinc-100 rounded w-1/4 mb-4" />
                <div className="h-2 bg-zinc-100 rounded" />
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-4xl mb-3">📂</p>
            <p className="text-zinc-500 text-sm">
              {search ? 'Aucun résultat' : 'Aucun site dans ce projet'}
            </p>
            {!search && (
              <button
                onClick={() => setShowModal(true)}
                className="mt-4 text-sm text-zinc-900 font-semibold underline underline-offset-2"
              >
                Ajouter le premier site
              </button>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map(site => {
              const { received, pending, missing, pct, isComplete } = getSiteStats(site)
              return (
                <button
                  key={site.id}
                  onClick={() => navigate(`/site/${site.id}`)}
                  className="w-full bg-white rounded-2xl p-5 text-left shadow-sm border border-zinc-100 active:scale-98 transition-transform hover:border-zinc-200"
                >
                  {/* Titre + badge */}
                  <div className="flex items-start justify-between mb-1">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-zinc-900 text-sm leading-tight">{site.name}</h3>
                      {site.bailleur && (
                        <p className="text-xs text-zinc-400 mt-0.5 truncate">{site.bailleur}</p>
                      )}
                    </div>
                    <span className={`ml-3 flex-shrink-0 text-xs font-bold px-2.5 py-1 rounded-full ${
                      isComplete
                        ? 'bg-emerald-50 text-emerald-700'
                        : pct > 0
                        ? 'bg-amber-50 text-amber-700'
                        : 'bg-zinc-100 text-zinc-500'
                    }`}>
                      {isComplete ? '✓ Complet' : `${pct}%`}
                    </span>
                  </div>

                  {/* Compteurs */}
                  <div className="flex gap-3 mt-2.5 mb-3">
                    <span className="flex items-center gap-1 text-xs text-emerald-600">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
                      {received} reçus
                    </span>
                    {pending > 0 && (
                      <span className="flex items-center gap-1 text-xs text-amber-600">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-400 inline-block" />
                        {pending} en attente
                      </span>
                    )}
                    {missing > 0 && (
                      <span className="flex items-center gap-1 text-xs text-zinc-400">
                        <span className="w-1.5 h-1.5 rounded-full bg-zinc-300 inline-block" />
                        {missing} manquants
                      </span>
                    )}
                  </div>

                  {/* Barre de progression segmentée */}
                  <div className="h-2 bg-zinc-100 rounded-full overflow-hidden flex gap-0.5">
                    {Array.from({ length: 15 }, (_, i) => {
                      const doc = (site.documents || [])[i]
                      const status = doc?.status || 'missing'
                      return (
                        <div
                          key={i}
                          className={`flex-1 h-full rounded-sm transition-all duration-300 ${
                            status === 'received' ? 'bg-emerald-500' :
                            status === 'pending'  ? 'bg-amber-400' :
                            'bg-zinc-200'
                          }`}
                        />
                      )
                    })}
                  </div>
                </button>
              )
            })}
          </div>
        )}
      </div>

      {/* Modal nouveau site */}
      {showModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center px-4 pb-4">
          <div className="bg-white rounded-2xl w-full max-w-sm p-6 shadow-xl">
            <h2 className="font-bold text-zinc-900 text-lg mb-4">Nouveau site</h2>
            <div className="mb-3">
              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wide mb-1">Nom du site *</label>
              <input
                autoFocus
                type="text"
                value={form.name}
                onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                placeholder="Ex : DJEBE MOUFOU"
                className="w-full px-3 py-3 border border-zinc-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-zinc-900"
                onKeyDown={e => e.key === 'Enter' && createSite()}
              />
            </div>
            <div className="mb-3">
              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wide mb-1">Bailleur</label>
              <input
                type="text"
                value={form.bailleur}
                onChange={e => setForm(f => ({ ...f, bailleur: e.target.value }))}
                placeholder="Ex : BELLO HAMADOU"
                className="w-full px-3 py-3 border border-zinc-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-zinc-900"
              />
            </div>
            <div className="mb-5">
              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wide mb-1">Région</label>
              <input
                type="text"
                value={form.region}
                onChange={e => setForm(f => ({ ...f, region: e.target.value }))}
                placeholder="Ex : Adamaoua"
                className="w-full px-3 py-3 border border-zinc-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-zinc-900"
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => { setShowModal(false); setForm({ name: '', bailleur: '', region: '' }) }}
                className="flex-1 py-3 border border-zinc-200 rounded-xl text-sm font-semibold text-zinc-600"
              >
                Annuler
              </button>
              <button
                onClick={createSite}
                disabled={saving || !form.name.trim()}
                className="flex-1 py-3 bg-zinc-900 text-white rounded-xl text-sm font-semibold disabled:opacity-50"
              >
                {saving ? 'Création...' : 'Créer'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
