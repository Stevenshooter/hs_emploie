import { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { DOCUMENTS, STATUS } from '../lib/constants'

export default function SitePage() {
  const { siteId } = useParams()
  const navigate = useNavigate()
  const [site, setSite] = useState(null)
  const [documents, setDocuments] = useState([])
  const [loading, setLoading] = useState(true)
  const [updating, setUpdating] = useState(null)
  const [noteOpen, setNoteOpen] = useState(null)
  const [noteText, setNoteText] = useState('')

  useEffect(() => { fetchData() }, [siteId])

  async function fetchData() {
    setLoading(true)
    const [{ data: siteData }, { data: docs }] = await Promise.all([
      supabase.from('sites')
        .select('id, name, bailleur, region, project_id')
        .eq('id', siteId)
        .single(),
      supabase.from('documents')
        .select('id, doc_type, status, notes, updated_at')
        .eq('site_id', siteId)
        .order('doc_type'),
    ])
    setSite(siteData)
    setDocuments(docs || [])
    setLoading(false)
  }

  async function cycleStatus(doc) {
    const next = STATUS[doc.status]?.next || 'pending'
    setUpdating(doc.id)
    // Optimistic update
    setDocuments(prev =>
      prev.map(d => d.id === doc.id ? { ...d, status: next } : d)
    )
    const { error } = await supabase
      .from('documents')
      .update({ status: next, updated_at: new Date().toISOString() })
      .eq('id', doc.id)
    if (error) {
      // Rollback
      setDocuments(prev =>
        prev.map(d => d.id === doc.id ? { ...d, status: doc.status } : d)
      )
    }
    setUpdating(null)
  }

  async function saveNote(doc) {
    await supabase.from('documents')
      .update({ notes: noteText.trim() || null })
      .eq('id', doc.id)
    setDocuments(prev =>
      prev.map(d => d.id === doc.id ? { ...d, notes: noteText.trim() || null } : d)
    )
    setNoteOpen(null)
    setNoteText('')
  }

  const received = documents.filter(d => d.status === 'received').length
  const pending  = documents.filter(d => d.status === 'pending').length
  const missing  = documents.filter(d => d.status === 'missing').length
  const pct = Math.round((received / 15) * 100)
  const isComplete = received === 15

  return (
    <div className="min-h-screen bg-zinc-100">
      {/* Header */}
      <div className="bg-white border-b border-zinc-200 px-4 py-4 sticky top-0 z-10">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center gap-3 mb-3">
            <button
              onClick={() => navigate(-1)}
              className="w-8 h-8 flex items-center justify-center rounded-lg bg-zinc-100 text-zinc-600 font-bold text-lg"
            >
              ‹
            </button>
            <div className="flex-1 min-w-0">
              <p className="text-xs text-zinc-400 font-medium uppercase tracking-widest">Dossier</p>
              <h1 className="text-lg font-bold text-zinc-900 truncate">{site?.name || '...'}</h1>
              {site?.bailleur && (
                <p className="text-xs text-zinc-400">{site.bailleur}</p>
              )}
            </div>
            <div className={`flex-shrink-0 text-center px-3 py-1.5 rounded-xl ${
              isComplete ? 'bg-emerald-50' : 'bg-zinc-50'
            }`}>
              <p className={`text-lg font-black ${isComplete ? 'text-emerald-600' : 'text-zinc-700'}`}>
                {pct}%
              </p>
              <p className="text-xs text-zinc-400">{received}/15</p>
            </div>
          </div>

          {/* Barre de progression globale */}
          <div className="h-2 bg-zinc-100 rounded-full overflow-hidden flex gap-px">
            {Array.from({ length: 15 }, (_, i) => {
              const doc = documents[i]
              const st = doc?.status || 'missing'
              return (
                <div
                  key={i}
                  className={`flex-1 h-full transition-all duration-300 ${
                    st === 'received' ? 'bg-emerald-500' :
                    st === 'pending'  ? 'bg-amber-400' : 'bg-zinc-200'
                  }`}
                />
              )
            })}
          </div>

          {/* Légende */}
          <div className="flex gap-4 mt-2 text-xs text-zinc-500">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
              {received} reçus
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-amber-400 inline-block" />
              {pending} en attente
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-zinc-300 inline-block" />
              {missing} manquants
            </span>
          </div>
        </div>
      </div>

      {/* Liste des 15 documents */}
      <div className="max-w-2xl mx-auto px-4 py-5">
        {loading ? (
          <div className="space-y-2">
            {Array.from({ length: 15 }, (_, i) => (
              <div key={i} className="bg-white rounded-xl p-4 animate-pulse">
                <div className="h-3.5 bg-zinc-100 rounded w-2/3" />
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-2">
            {DOCUMENTS.map(docDef => {
              const doc = documents.find(d => d.doc_type === docDef.id)
              if (!doc) return null
              const st = STATUS[doc.status] || STATUS.missing
              const isUpdating = updating === doc.id

              return (
                <div
                  key={docDef.id}
                  className="bg-white rounded-xl border border-zinc-100 shadow-sm overflow-hidden"
                >
                  <div className="flex items-center gap-3 px-4 py-3.5">
                    {/* Numéro */}
                    <span className="text-xs font-bold text-zinc-300 w-5 flex-shrink-0 text-center">
                      {docDef.id}
                    </span>

                    {/* Libellé */}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-zinc-800 font-medium leading-tight">{docDef.label}</p>
                      {doc.notes && (
                        <p className="text-xs text-zinc-400 mt-0.5 truncate">📝 {doc.notes}</p>
                      )}
                    </div>

                    {/* Bouton note */}
                    <button
                      onClick={() => {
                        setNoteOpen(doc.id === noteOpen ? null : doc.id)
                        setNoteText(doc.notes || '')
                      }}
                      className="w-7 h-7 flex items-center justify-center rounded-lg text-zinc-300 hover:text-zinc-500 hover:bg-zinc-50 flex-shrink-0 transition-colors"
                    >
                      ✏️
                    </button>

                    {/* Badge statut — tap pour changer */}
                    <button
                      onClick={() => cycleStatus(doc)}
                      disabled={isUpdating}
                      className={`flex-shrink-0 flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all active:scale-95 ${st.color} ${isUpdating ? 'opacity-50' : ''}`}
                    >
                      <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${st.dot}`} />
                      {st.label}
                    </button>
                  </div>

                  {/* Zone note (expandable) */}
                  {noteOpen === doc.id && (
                    <div className="px-4 pb-3 border-t border-zinc-50 bg-zinc-50">
                      <textarea
                        autoFocus
                        value={noteText}
                        onChange={e => setNoteText(e.target.value)}
                        placeholder="Ajouter une note (ex : manque signature, à récupérer...)"
                        rows={2}
                        className="w-full mt-2 px-3 py-2 text-xs border border-zinc-200 rounded-lg bg-white resize-none focus:outline-none focus:ring-2 focus:ring-zinc-900"
                      />
                      <div className="flex gap-2 mt-2">
                        <button
                          onClick={() => { setNoteOpen(null); setNoteText('') }}
                          className="flex-1 py-1.5 text-xs font-semibold text-zinc-500 border border-zinc-200 rounded-lg bg-white"
                        >
                          Annuler
                        </button>
                        <button
                          onClick={() => saveNote(doc)}
                          className="flex-1 py-1.5 text-xs font-semibold text-white bg-zinc-900 rounded-lg"
                        >
                          Enregistrer
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        )}

        {/* Badge complet */}
        {isComplete && !loading && (
          <div className="mt-4 p-4 bg-emerald-50 border border-emerald-100 rounded-2xl text-center">
            <p className="text-emerald-700 font-bold text-sm">✓ Dossier complet</p>
            <p className="text-emerald-500 text-xs mt-0.5">Les 15 documents sont reçus</p>
          </div>
        )}
      </div>
    </div>
  )
}
