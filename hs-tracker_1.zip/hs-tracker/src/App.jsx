import { BrowserRouter, Routes, Route } from 'react-router-dom'
import ProjectsPage from './pages/ProjectsPage'
import ProjectPage from './pages/ProjectPage'
import SitePage from './pages/SitePage'

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<ProjectsPage />} />
        <Route path="/project/:projectId" element={<ProjectPage />} />
        <Route path="/site/:siteId" element={<SitePage />} />
      </Routes>
    </BrowserRouter>
  )
}
